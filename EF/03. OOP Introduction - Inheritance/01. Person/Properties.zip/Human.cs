﻿public abstract class Human
{
    protected string name;

    protected int age;

    //public virtual string Name { get; set; }

    //public virtual int Age { get; set; }

    public Human()
    {

    }

    //public override string ToString()
    //{
    //    return $"Name: {this.Name}, Age: {this.Age}";
    //}
}
