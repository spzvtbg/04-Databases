﻿namespace Instagraph.DataProcessor.ImportDtos
{
    public class PictureDto
    {
        public string Path { get; set; }

        public decimal Size { get; set; }
    }
}
