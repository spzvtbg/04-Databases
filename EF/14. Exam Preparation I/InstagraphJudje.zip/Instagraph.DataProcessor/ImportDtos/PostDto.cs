﻿namespace Instagraph.DataProcessor.ImportDtos
{
    public class PostDto
    {
        public string caption { get; set; }

        public string user { get; set; }

        public string picture { get; set; }
    }
}
