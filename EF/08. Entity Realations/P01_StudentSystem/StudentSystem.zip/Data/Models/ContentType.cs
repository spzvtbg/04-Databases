﻿namespace P01_StudentSystem.Data.Models
{
    public enum ContentType
    {
        Aplication = 1,
        Pdf = 2,
        Zip = 3
    }
}