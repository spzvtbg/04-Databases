namespace FastFood.Data
{
	public static class Configuration
	{
        //DESKTOP-0NANS27\SQLEXPRESS
        public static string ConnectionString =
            @"Server=.;Database=FastFood;Trusted_Connection=True";
	}
}