﻿namespace FastFood.DataProcessor.Dto
{
    public class OrderItemDto
    {
        public string Name { get; set; }

        public string Quantity { get; set; }
    }
}
