﻿namespace FastFood.DataProcessor.Dto.Export
{
    public class CategoryDto
    {
        public string Name { get; set; }
        public ItemDto MostPopularItem { get; set; }
    }
}